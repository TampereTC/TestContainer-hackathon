/* global define */
define({
    foo: function () {
        return 42;
    }
});
