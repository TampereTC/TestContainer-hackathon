require(['foo'], function (foo) {
    window.foo = foo.foo();
});
