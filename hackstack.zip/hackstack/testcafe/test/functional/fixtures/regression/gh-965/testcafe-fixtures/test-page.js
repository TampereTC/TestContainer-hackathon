fixture `GH-965`;

test
    .page `httpss://example.com`
('test.page', () => {

});
