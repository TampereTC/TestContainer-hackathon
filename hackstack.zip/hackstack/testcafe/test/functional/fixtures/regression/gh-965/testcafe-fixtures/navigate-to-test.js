fixture `GH-965`;

test('navigateTo', async t => {
    await t.navigateTo('httpss://example.com');
});
