it("[Regression](T116171) Custom selectors don't work, if they're passed directly into action", function () {
    return runTests('testcafe-fixtures/index.test.js');
});
