it('[Regression](T171129) Test running is hung on the MVCxImageAndDataNavigationDemos/ImageSlider/VideoGallery demo page', function () {
    return runTests('testcafe-fixtures/index.test.js');
});
