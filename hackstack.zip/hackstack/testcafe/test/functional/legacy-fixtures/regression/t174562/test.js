it('[Regression](T174562) jQuery UI selectmenu demo: click on popup item is out of popup bounds during playback in Chrome', function () {
    return runTests('testcafe-fixtures/index.test.js');
});
