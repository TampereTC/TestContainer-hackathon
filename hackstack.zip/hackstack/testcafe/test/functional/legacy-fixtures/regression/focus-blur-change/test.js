it('[Regression] Should pass if blur, change and focus events were raised in same-domain iframe', function () {
    return runTests('testcafe-fixtures/index.test.js');
});
