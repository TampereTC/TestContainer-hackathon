it("Pressing CTRL+SHIFT+key combinations shouldn't be prevented", function () {
    return runTests('testcafe-fixtures/index.test.js');
});
