it('[Regression](T190110) The next step is skipped if a server responds too long after clicking a link in the previous step in IE', function () {
    return runTests('testcafe-fixtures/index.test.js');
});
