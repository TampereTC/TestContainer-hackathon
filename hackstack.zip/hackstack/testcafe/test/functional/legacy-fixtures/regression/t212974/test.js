it("[Regression](T212974) Page script can't get element under TestCafe cursor with document.elementFromPoint in IE", function () {
    return runTests('testcafe-fixtures/index.test.js');
});
