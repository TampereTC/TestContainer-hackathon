it('[Regression] Should prevent real action in same-domain iframe', function () {
    return runTests('testcafe-fixtures/index.test.js');
});
