/*eslint-disable no-unused-vars*/
function getInput () {
    return $('#input');
}
/*eslint-enable no-unused-vars*/
