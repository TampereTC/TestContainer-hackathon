import { Selector } from 'testcafe';

fixture `Test`;

Selector(() => {}).nth('hey');

test('yo', () => {
});
