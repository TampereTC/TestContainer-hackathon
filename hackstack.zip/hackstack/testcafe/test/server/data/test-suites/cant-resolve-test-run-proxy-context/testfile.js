import { t } from 'testcafe';

fixture `Some fixture`;

t.click('div');

test('Some test', async () => {

});
