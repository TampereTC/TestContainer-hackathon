fixture `afterEach is not a function`
    .afterEach('yo');

test('Some test', () => {

});
