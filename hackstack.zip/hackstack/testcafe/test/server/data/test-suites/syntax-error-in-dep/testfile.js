import dep from './dep';

fixture `Syntax error in dep`;

test('Dummy', () => {
});
