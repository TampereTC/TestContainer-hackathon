import { Role } from 'testcafe';

fixture `Test`;

Role(123, () => {});

test('yo', () => {
});
