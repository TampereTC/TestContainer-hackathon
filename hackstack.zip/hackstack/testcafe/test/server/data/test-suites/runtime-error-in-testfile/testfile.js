fixture `Syntax error in testfile`;

test('Dummy', () => {
});

throw new Error('Hey ya!');
