import { Selector } from 'testcafe';

fixture `Test`;

Selector(() => {}).nth(Infinity);

test('yo', () => {
});
