import { Selector } from 'testcafe';

fixture `Test`;

Selector(() => {}).withText({});

test('yo', () => {
});
