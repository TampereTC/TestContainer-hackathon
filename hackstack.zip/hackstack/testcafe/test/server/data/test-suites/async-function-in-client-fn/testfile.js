import { ClientFunction } from 'testcafe';

fixture `Test`;

ClientFunction(async function () {
});

test('yo', () => {
});
