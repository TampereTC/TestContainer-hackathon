export default async function (t) {
    throw new Error();
}
