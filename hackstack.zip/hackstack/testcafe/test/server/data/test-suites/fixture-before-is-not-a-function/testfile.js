fixture `before is not a function`
    .before('yo');

test('Some test', () => {

});
