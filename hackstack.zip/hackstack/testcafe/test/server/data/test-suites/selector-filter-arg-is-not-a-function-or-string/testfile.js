import { Selector } from 'testcafe';

fixture `Test`;

Selector('span').filter({});

test('yo', () => {
});
