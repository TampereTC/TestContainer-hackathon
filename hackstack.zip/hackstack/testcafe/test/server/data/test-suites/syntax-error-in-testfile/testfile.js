import export test;

fixture `Syntax error in testfile`;

test('Dummy', () => {
});
