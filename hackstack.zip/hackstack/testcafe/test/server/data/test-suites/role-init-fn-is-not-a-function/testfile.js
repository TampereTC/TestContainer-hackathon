import { Role } from 'testcafe';

fixture `Test`;

Role('exampe.com', 123);

test('yo', () => {
});
