fixture `Yo`
    .page({ answer: 42 });

test('Test', () => {
    return 'yo';
});

