import { ClientFunction } from 'testcafe';

fixture `Test`;

var h = new ClientFunction(123);

test('yo', () => {
});
