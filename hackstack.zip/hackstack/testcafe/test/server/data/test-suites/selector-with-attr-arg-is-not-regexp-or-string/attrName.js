import { Selector } from 'testcafe';

fixture `Test`;

Selector(() => {}).withAttribute(null);

test('yo', () => {
});
