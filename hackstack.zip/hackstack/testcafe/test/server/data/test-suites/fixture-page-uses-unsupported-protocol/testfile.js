fixture `page uses an unsupported protocol`
    .page`mail://yourname@yourcompany.com`;

test('Test', () => {

});
