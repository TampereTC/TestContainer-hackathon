fixture('Fixture1')
    .page('http://example.com')
    .meta();

test
    ('Fixture1Test1', async () => {
        // do nothing
    });
