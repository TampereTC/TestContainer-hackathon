import exportableLib from 'testcafe';

export default exportableLib;
