export const FOO = 42;
