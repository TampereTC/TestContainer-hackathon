import { Selector } from 'testcafe';

fixture `Test`;

Selector(123);

test('yo', () => {
});
