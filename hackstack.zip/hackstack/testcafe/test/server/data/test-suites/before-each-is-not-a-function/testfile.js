fixture `beforeEach is not a function`
    .beforeEach('yo');

test('Some test', () => {

});
