import yo from './yo';

fixture `Require error in testfile`;

test('Dummy', () => {
});
