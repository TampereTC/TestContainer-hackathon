fixture `after is not a function`
    .after('yo');

test('Some test', () => {

});
