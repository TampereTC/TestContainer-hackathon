import { ClientFunction } from 'testcafe';

fixture `Test`;

ClientFunction(123);

test('yo', () => {
});
