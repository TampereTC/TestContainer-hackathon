fixture `Fixture`;

test.after(123)('Some test', () => {

});
