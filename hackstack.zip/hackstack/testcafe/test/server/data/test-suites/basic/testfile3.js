var myFixture = fixture('Fixture4');

test('F4T1', async t => {
    await t.wait(100);
});
