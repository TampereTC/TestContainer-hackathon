export default function () {
    return 'Hey from dep1';
};
