fixture `Fixture`;

test
  .meta({ run: 'run-001' })
  ('1.Test', () => {

  });
