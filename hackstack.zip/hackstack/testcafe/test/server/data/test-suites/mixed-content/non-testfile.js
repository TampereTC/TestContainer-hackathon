function someUtilityFunc () {
    console.log('yo');
}
