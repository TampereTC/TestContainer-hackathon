fixture `RequestHook is undefined`
    .requestHooks('string');

test('test', async t => {
});
