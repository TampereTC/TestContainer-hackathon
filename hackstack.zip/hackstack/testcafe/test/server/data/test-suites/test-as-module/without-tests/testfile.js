import libraryTest from './lib';

libraryTest();
