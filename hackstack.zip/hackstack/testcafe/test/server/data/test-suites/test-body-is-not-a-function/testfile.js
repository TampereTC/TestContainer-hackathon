fixture `Test body is not a function`;

test('Test', 'Yo');
