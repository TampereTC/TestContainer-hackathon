fixture `Username is not defined`
    .httpAuth({ password: 'password' });

test('Some test', () => {

});
