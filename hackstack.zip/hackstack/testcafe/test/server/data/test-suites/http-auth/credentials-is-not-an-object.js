fixture `Credentials is not an object`
    .httpAuth('');

test('Some test', () => {

});
