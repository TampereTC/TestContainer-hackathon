import Yo from './yo';

export var answer = 42;
