import dep from './dep';

fixture `Require error in dep`;

test('Dummy', () => {
});
