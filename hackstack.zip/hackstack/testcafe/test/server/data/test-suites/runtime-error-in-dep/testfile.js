import dep from './dep';

fixture `Runtime error in dep`;

test('Dummy', () => {
});
