import { Selector } from 'testcafe';

fixture `Test`;

Selector('span').find({});

test('yo', () => {
});
