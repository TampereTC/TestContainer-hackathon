(function () {
    return function fn_123$$ () {
        return true;
    };
})();
