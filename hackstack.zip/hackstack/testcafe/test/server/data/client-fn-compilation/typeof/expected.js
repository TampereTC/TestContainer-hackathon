(function () {
    var _typeof = function (obj) {
        return typeof obj;
    };
    return (function () {
        return typeof someObj === "undefined" ? "undefined" : _typeof(someObj);
    });
})();
