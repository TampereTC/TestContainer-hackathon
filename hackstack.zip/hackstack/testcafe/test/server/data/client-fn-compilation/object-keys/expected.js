(function () {
    var _keys2 = { default: Object.keys };
    return (function () {
        return (0, _keys2.default)(SomeClass.prototype).forEach(function (prop) {
            return prop;
        });
    });
})();
