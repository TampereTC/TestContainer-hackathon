---
layout: post
title: TestCafe v0.18.0-alpha1 Released - Testing in headless Firefox
permalink: /blog/:title.html
---
# TestCafe v0.18.0-alpha1 Released: Testing in headless Firefox

This early release supports headless mode in Firefox v56.0 which was launched on September 28th.

<!--more-->

To run your tests in headless mode, use the following command:

```sh
testcafe firefox:headless test.js
```

A major release of TestCafe v0.18.0 with a bunch of new features is coming soon.
